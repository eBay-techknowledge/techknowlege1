

### 0.1.15 - 05/05/2016

 Changes: 


 * #7 - make only one request for google fonts
 * Merge pull request #67 from cristian-ungureanu/development

Development
 *  Fixed issue with Jetpack sharing on latest news section #68


### 0.1.14 - 13/04/2016

 Changes: 


 * Fixed WP 4.5 menu issue

Fixed jQuery issue which was caused with WP 4.5
 * Merge pull request #58 from HardeepAsrani/development

Fixed WP 4.5 menu issue


### 0.1.13 - 06/04/2016

 Changes: 


 * fixed icons in customizer
 * Merge pull request #54 from cristian-ungureanu/development

fixed icons in customizer


### 0.1.12 - 01/04/2016

 Changes: 


 * Update pot file
 * Big title section background issue
 * Merge pull request #47 from cristian-ungureanu/development

Development


### 0.1.11 - 25/03/2016

 Changes: 


 * Added Eventbrite API plugin compatibility #44


### 0.1.9 - 23/03/2016

 Changes: 


 * Option to change the Call us text in the very top header #36
 * Added an option to change the overlay color and transparency of the header image #37
 * Option to change the page template to full width site-wide #27
 * Footer widgets underline issue #41


### 0.1.8 - 22/03/2016

 Changes: 


 * Merge pull request #33 from abaicus/development

Changed widget title style and CSS selectors for the github tab in the about screen on dashboard.


### 0.1.7 - 10/03/2016

 Changes: 


 * Merge pull request #28 from abaicus/development

!!!Restyled Contribute section.
 * Fixed socials icons cant be removed completely  #31


### 0.1.5 - 03/03/2016

 Changes: 


 * #18 Options to hide frontpage sections
 * Recommend Llorix One Companion plugin


### 0.1.4 - 02/03/2016

 Changes: 


 * Removed notices
 * Fixed #15 Icons do not seem to work on blog


### 0.1.3 - 01/03/2016

 Changes: 


 * Merge pull request #8 from cristian-ungureanu/development

!!! fix translation for links, added font awesome in readme


### 0.1.2 - 26/02/2016

 Changes: 


 * New screenshot
 * Merge pull request #4 from abaicus/development

!!!Fixed responsive issues in About Llorix One Lite dashboard screen.
 * Merge pull request #5 from cristian-ungureanu/development

!!! fixed translation issues
 * Merge pull request #6 from cristian-ungureanu/development

!!! fix footer and social icons
